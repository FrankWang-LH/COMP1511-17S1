Don't push work to this repository directly or
change it via the web interface

Submit your work using give, and it will be pushed to the repository directly.

