// 16.04.2017
// Frank Wang 
// Crack bpm images - changed from test_horizontal_balance.c

#include <stdio.h>
#include "captcha.h"

int main(int argc, char *argv[]) {
    int height, width, start_row, start_column, box_width, box_height;
    double hor_balance = 0;
    double ver_balance = 0;
    double density = 0;
    double tallness = 0;
    int number = 0;
    int conditions = 0;
    int half = 0;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <image-file>\n", argv[0]);
        return 1;
    }

    if (get_pbm_dimensions(argv[1], &height, &width) != 1) {
        return 1;
    }

    int pixels[height][width];
    if (read_pbm(argv[1], height, width, pixels)) {
        get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);

        int box_pixels[box_height][box_width];
        copy_pixels(height, width, pixels, start_row, start_column, box_height, box_width, box_pixels);

        hor_balance = get_horizontal_balance(box_height, box_width, box_pixels);

        ver_balance = get_vertical_balance(box_height, box_width,box_pixels);

        density = find_density(box_height,box_width,box_pixels);

        tallness = find_tallness(box_height,box_width,box_pixels);
        
        conditions = condition(box_height,box_width,box_pixels);

        //number = holes(height,width,pixels,conditions);

        half = halves(height,width,pixels,conditions);

        number = holes(height,width,pixels);

        //printf("density %.3lf\n",density);
        //printf("tallness %.3lf\n",tallness);
        //printf("horizontal balance %.3lf\n",hor_balance);
        //printf("vertical balance %.3lf\n",ver_balance);
        
        //printf("%d\n",half);
        //printf("%d\n",conditions);
        printf("number %d\n",number);
        if(number == 2){
            printf("8\n");
        } else if(number == 1){
            printf("0\n");
             
        } else {
            if(hor_balance > 0.525 && ver_balance > 0.535){
                printf("7\n");
            } else if(conditions == 4 || conditions == 2){
                printf("5\n");
            } else if(conditions == 2 || conditions == 3){
                printf("2\n");
            } else if(hor_balance > 0.52 && ver_balance < 0.53){
                printf("3\n");
            }
        }

    }
    

    return 0;
}






