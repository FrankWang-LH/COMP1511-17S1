// Frank Wang
// 17/04/2017
// horizontal scan for assessment 1

#include <stdio.h>
#include <stdlib.h>
#include "captcha.h" 

void hor_scan(int height, int width, int pixels[height][width], int h_scan[height]){

    int i = height - 1;
    int j = 0;

    while(j < height){    
        h_scan[j] = 0;
        j = j + 1;
    }

    while(i >= 0){
        j = 0;
        while(j < width){
            if(pixels[i][j] == 1 && j != width - 1){
                if(pixels[i][j + 1] == 0){
                    h_scan[i] = h_scan[i] + 1;
                } 
            } else if(pixels[i][j]==1 && j == width-1){
                h_scan[i] = h_scan[i] + 1;
            }
            j = j + 1;
        }

    i = i - 1;
    } 



}
