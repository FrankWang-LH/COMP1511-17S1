// Frank Wang <zhenqi.wang@student.unsw.edu.au>
// MAY 2017
// return bot name

char *get_bot_name(void){
    // RETURN NAME
    return "Transport_Buses";
}
